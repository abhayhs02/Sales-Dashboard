Hello this is a learning dashboard created in react using vanilla JS and d3.js
